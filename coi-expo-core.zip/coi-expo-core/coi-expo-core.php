<?php
/**
 * Plugin Name: COI Global Events - Conference Edition (v10.0)
 * Description: Event Intelligence with dedicated Conference Tracks & Virtual Modes.
 * Version: 10.0.0
 * Author: COI
 */

if (!defined('ABSPATH')) exit;

/* ======================================================
   1. DATA STRUCTURES
   ====================================================== */
add_action('init', function () {
    register_post_type('coi_expo', [
        'labels' => ['name' => 'Global Events', 'singular_name' => 'Event', 'add_new_item' => 'Add Event'],
        'public' => true,
        'menu_icon' => 'dashicons-networking',
        'supports' => ['title', 'editor', 'excerpt'],
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'global-events', 'with_front' => false], 
        'has_archive' => true
    ]);
    register_taxonomy('coi_expo_cat', 'coi_expo', [
        'labels' => ['name' => 'Industries', 'singular_name' => 'Industry'],
        'hierarchical' => true,
        'show_ui' => true,
    ]);
    register_taxonomy('coi_expo_loc', 'coi_expo', [
        'labels' => ['name' => 'Locations', 'singular_name' => 'Location'],
        'hierarchical' => true,
        'show_ui' => true,
    ]);
});

/* ======================================================
   2. META BOXES (Added Conference Fields)
   ====================================================== */
add_action('add_meta_boxes', function () {
    add_meta_box('coi_expo_data', 'Event Details', 'coi_expo_meta_box', 'coi_expo', 'normal', 'high');
});

function coi_expo_meta_box($post) {
    wp_nonce_field('coi_expo_save', 'coi_expo_nonce');
    $get = fn($k) => get_post_meta($post->ID, "_cx_$k", true);
    ?>
    <style>.cx-row { display: flex; gap: 15px; margin-bottom: 10px; } .cx-col { flex: 1; } input, textarea, select { width: 100%; padding: 8px; }</style>
    <div class="cx-wrap">
        
        <div class="cx-row" style="background: #f0fdf4; padding: 10px; border-radius: 8px;">
            <div class="cx-col"><label>Event Format</label>
                <select name="cx_format">
                    <option value="in-person" <?= selected($get('format'), 'in-person') ?>>🏢 In-Person Only</option>
                    <option value="virtual" <?= selected($get('format'), 'virtual') ?>>💻 Virtual Only</option>
                    <option value="hybrid" <?= selected($get('format'), 'hybrid') ?>>🌐 Hybrid (Live + Virtual)</option>
                </select>
            </div>
            <div class="cx-col"><label>Virtual/Stream Link</label><input type="text" name="cx_conf_link" value="<?= esc_attr($get('conf_link')) ?>" placeholder="https://zoom.us/..."></div>
        </div>

        <div class="cx-row">
            <div class="cx-col"><label>Start Date</label><input type="date" name="cx_start_date" value="<?= esc_attr($get('start_date')) ?>"></div>
            <div class="cx-col"><label>End Date</label><input type="date" name="cx_end_date" value="<?= esc_attr($get('end_date')) ?>"></div>
            <div class="cx-col"><label>Venue</label><input type="text" name="cx_venue" value="<?= esc_attr($get('venue')) ?>"></div>
        </div>
        
        <div class="cx-row">
            <div class="cx-col"><label>Verified Partner?</label>
                <select name="cx_verified">
                    <option value="">No</option>
                    <option value="1" <?= selected($get('verified'), '1') ?>>🏆 Yes</option>
                </select>
            </div>
            <div class="cx-col"><label>Brochure URL</label><input type="text" name="cx_brochure" value="<?= esc_attr($get('brochure')) ?>"></div>
        </div>

        <div class="cx-row"><div class="cx-col"><label>Conference Highlights (One per line)</label><textarea name="cx_conf_highlights" rows="3"><?= esc_textarea($get('conf_highlights')) ?></textarea></div></div>
        
        <div class="cx-row"><div class="cx-col"><label>Agenda</label><textarea name="cx_agenda" rows="3"><?= esc_textarea($get('agenda')) ?></textarea></div></div>
        <div class="cx-row"><div class="cx-col"><label>Why Attend</label><textarea name="cx_why_attend" rows="3"><?= esc_textarea($get('why_attend')) ?></textarea></div></div>
        <div class="cx-row"><div class="cx-col"><label>Why Exhibit</label><textarea name="cx_why_exhibit" rows="3"><?= esc_textarea($get('why_exhibit')) ?></textarea></div></div>
    </div>
    <?php
}

add_action('save_post_coi_expo', function ($post_id) {
    if (!isset($_POST['coi_expo_nonce']) || !wp_verify_nonce($_POST['coi_expo_nonce'], 'coi_expo_save')) return;
    $fields = ['start_date','end_date','venue','verified','brochure','format','conf_link','conf_highlights','agenda','why_attend','why_exhibit'];
    foreach ($fields as $f) {
        if (isset($_POST["cx_$f"])) update_post_meta($post_id, "_cx_$f", sanitize_text_field($_POST["cx_$f"]));
        if (in_array($f, ['agenda', 'why_attend', 'why_exhibit', 'conf_highlights']) && isset($_POST["cx_$f"])) {
            update_post_meta($post_id, "_cx_$f", sanitize_textarea_field($_POST["cx_$f"]));
        }
    }
});

/* ======================================================
   3. VISITOR FORM HANDLER
   ====================================================== */
add_action('admin_post_nopriv_cx_visitor_form', 'cx_handle_visitor_form');
add_action('admin_post_cx_visitor_form', 'cx_handle_visitor_form');

function cx_handle_visitor_form() {
    if (!isset($_POST['_cx_nonce']) || !wp_verify_nonce($_POST['_cx_nonce'], 'cx_visitor_action')) wp_die('Security check failed.');
    
    $event_id = intval($_POST['event_id']);
    $event_name = get_the_title($event_id);
    $name = sanitize_text_field($_POST['cx_name']);
    $email = sanitize_email($_POST['cx_email']);
    $company = sanitize_text_field($_POST['cx_company']);

    $to = get_option('admin_email'); 
    $subject = "🎟️ New Pass Request: $event_name";
    $message = "New lead captured:\n\nName: $name\nEmail: $email\nCompany: $company\n\nPlease process this request.";
    
    wp_mail($to, $subject, $message, ['Content-Type: text/plain; charset=UTF-8']);
    wp_redirect(get_permalink($event_id) . '?cx_success=1');
    exit;
}

/* ======================================================
   4. ASSETS
   ====================================================== */
add_filter('template_include', function ($t) {
    if (is_singular('coi_expo')) return plugin_dir_path(__FILE__) . 'templates/single-coi_expo.php';
    if (is_post_type_archive('coi_expo') || is_tax('coi_expo_cat') || is_tax('coi_expo_loc')) return plugin_dir_path(__FILE__) . 'templates/archive-coi_expo.php';
    return $t;
});

add_action('wp_enqueue_scripts', function () {
    if (is_post_type_archive('coi_expo') || is_tax('coi_expo_cat') || is_tax('coi_expo_loc') || is_singular('coi_expo')) {
        wp_enqueue_style('coi-expo-css', plugin_dir_url(__FILE__) . 'assets/coi-expo.css', [], '10.0');
        wp_enqueue_style('coi-fonts', 'https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;700;800&display=swap');
    }
});

/* ======================================================
   ADMIN: BULK IMPORT ENGINE (Restored)
   ====================================================== */
add_action('admin_menu', function() {
    // Adds "Import Expos" under the "Global Events" menu
    add_submenu_page(
        'edit.php?post_type=coi_expo', 
        'Import Events', 
        'Import Events', 
        'manage_options', 
        'coi-expo-import', 
        'cx_render_import_page'
    );
});

function cx_render_import_page() {
    // Handle Form Submission
    if (isset($_POST['cx_json']) && check_admin_referer('cx_import', 'cx_nonce')) {
        $json_raw = stripslashes($_POST['cx_json']);
        $data = json_decode($json_raw, true);

        if (!$data) {
            echo '<div class="notice notice-error"><p>❌ Invalid JSON format.</p></div>';
        } else {
            $count = 0;
            foreach ($data as $item) {
                // 1. Create the Post
                $pid = wp_insert_post([
                    'post_title'   => $item['title'],
                    'post_content' => $item['description'],
                    'post_type'    => 'coi_expo',
                    'post_status'  => 'publish'
                ]);

                if ($pid) {
                    $count++;

                    // 2. Map Meta Fields (All Versions)
                    $keys = [
                        'start_date', 'end_date', 'venue', 'footfall', 'exhibitors',
                        'booth_price', 'reg_link', 'verified', 'speakers', 
                        'agenda', 'why_attend', 'why_exhibit', 'brochure',
                        'format', 'conf_link', 'conf_highlights' // v10.0 Fields
                    ];

                    foreach ($keys as $k) {
                        if (isset($item[$k])) {
                            update_post_meta($pid, "_cx_$k", $item[$k]);
                        }
                    }

                    // 3. Map Taxonomies (Industries & Locations)
                    if (!empty($item['category'])) {
                        wp_set_object_terms($pid, $item['category'], 'coi_expo_cat');
                    }
                    if (!empty($item['location'])) {
                        // Save as Taxonomy for Search
                        wp_set_object_terms($pid, $item['location'], 'coi_expo_loc');
                        // Save as Meta for Display
                        update_post_meta($pid, '_cx_location', $item['location']); 
                    }
                }
            }
            echo '<div class="notice notice-success"><p>✅ Successfully imported ' . $count . ' events!</p></div>';
        }
    }
    
    // Render the Page
    ?>
    <div class="wrap">
        <h1 style="margin-bottom:20px;">🚀 Import Global Events</h1>
        <div style="background:#fff; padding:20px; border:1px solid #ccd0d4; border-left:4px solid #2271b1; box-shadow:0 1px 1px rgba(0,0,0,.04);">
            <h3 style="margin-top:0;">Paste JSON Payload</h3>
            <p>Paste your JSON array below to bulk create Expos, Summits, and Hybrid Events.</p>
            <form method="post">
                <?php wp_nonce_field('cx_import', 'cx_nonce'); ?>
                <textarea name="cx_json" rows="12" style="width:100%; font-family:monospace; background:#f0f0f1; border:1px solid #ddd; padding:10px;" placeholder='[{"title":"Event Name"...}]'></textarea>
                <p><input type="submit" class="button button-primary button-large" value="Run Import"></p>
            </form>
        </div>
    </div>
    <?php
}

