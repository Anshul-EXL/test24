<?php
/**
 * Discovery Archive - Faceted Search
 */
get_header(); 
$active_inds = isset($_GET['industry']) ? explode(',', $_GET['industry']) : [];
$active_locs = isset($_GET['location']) ? explode(',', $_GET['location']) : [];
?>

<div class="cx-archive-wrapper">
    <div class="cx-search-hero">
        <div class="cx-container">
            <h1>Global Innovation Calendar</h1>
            <p>Discover verified expos and summits.</p>
            <form role="search" method="get" class="cx-search-bar" action="<?= home_url('/') ?>">
                <input type="hidden" name="post_type" value="coi_expo">
                <input type="text" name="s" placeholder="Search events..." value="<?= get_search_query() ?>">
                <button type="submit">Search</button>
            </form>
        </div>
    </div>

    <div class="cx-container cx-archive-layout">
        <aside class="cx-filter-sidebar">
            <form id="cx-filter-form" method="GET" action="<?= get_post_type_archive_link('coi_expo') ?>">
                <div class="filter-group"><h3>🌍 Locations</h3>
                    <?php foreach(get_terms(['taxonomy'=>'coi_expo_loc','hide_empty'=>true]) as $t): ?>
                    <label class="cx-checkbox"><input type="checkbox" name="location[]" value="<?= $t->slug ?>" <?= in_array($t->slug,$active_locs)?'checked':'' ?> onchange="this.form.submit()"> <?= $t->name ?></label>
                    <?php endforeach; ?>
                </div>
                <div class="filter-group"><h3>🏭 Industry</h3>
                    <?php foreach(get_terms(['taxonomy'=>'coi_expo_cat','hide_empty'=>true]) as $t): ?>
                    <label class="cx-checkbox"><input type="checkbox" name="industry[]" value="<?= $t->slug ?>" <?= in_array($t->slug,$active_inds)?'checked':'' ?> onchange="this.form.submit()"> <?= $t->name ?></label>
                    <?php endforeach; ?>
                </div>
                <a href="<?= get_post_type_archive_link('coi_expo') ?>" class="cx-reset-btn">Reset Filters</a>
            </form>
        </aside>

        <main class="cx-results">
            <?php if (have_posts()) : ?>
                <div class="cx-cards-list">
                    <?php while (have_posts()) : the_post(); 
                        $id = get_the_ID(); $start = get_post_meta($id,'_cx_start_date',true); $venue = get_post_meta($id,'_cx_venue',true); $verified = get_post_meta($id,'_cx_verified',true)=='1';
                    ?>
                    <a href="<?php the_permalink(); ?>" class="cx-list-card <?= $verified?'verified-card':'' ?>">
                        <div class="cx-lc-date"><span class="lc-month"><?= date('M', strtotime($start)) ?></span><span class="lc-day"><?= date('d', strtotime($start)) ?></span></div>
                        <div class="cx-lc-info">
                            <div class="lc-top"><?php if($verified): ?><span class="badge-pro">🏆 Premier</span><?php endif; ?></div>
                            <h3><?php the_title(); ?></h3><p class="lc-meta"><?= $venue ?></p>
                        </div>
                        <div class="cx-lc-action"><span class="btn-view">View →</span></div>
                    </a>
                    <?php endwhile; ?>
                </div>
                <div class="cx-pagination"><?php echo paginate_links(); ?></div>
            <?php else : ?><div class="cx-no-results"><h3>No events found.</h3></div><?php endif; ?>
        </main>
    </div>
</div>
<?php get_footer(); ?>