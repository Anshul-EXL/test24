<?php
/**
 * Single Event Template - "Davos Tier" Edition (v16.0)
 * Features: Dark Mode Scores, Delegate Demographics, and Networking Intel.
 */
get_header();

$id = get_the_ID();
$get = fn($k) => get_post_meta($id, "_cx_$k", true);

// 1. DETECT MODE
$format = $get('format') ?: 'in-person';
$type_term = get_the_terms($id, 'coi_expo_cat');
$category = $type_term ? strtolower($type_term[0]->name) : '';
$is_summit = ($format === 'virtual' || $format === 'hybrid' || strpos($category, 'conference') !== false || strpos($category, 'summit') !== false);

// 2. DATA PREP
$start = $get('start_date');
$end = $get('end_date');
$venue = $get('venue');
$speakers = array_filter(array_map('trim', explode(',', $get('speakers'))));
$promoter_name = $get('promoter_name');
$promoter_link = $get('promoter_link');

// SCORES
$s_inn = $get('score_inn') ?: '8.8'; // Slightly higher defaults for summits
$s_net = $get('score_net') ?: '9.2';
$s_roi = $get('score_roi') ?: '8.5';
$avg_score = number_format(($s_inn + $s_net + $s_roi) / 3, 1);
?>

<?php if ($is_summit): ?>

    <div class="summit-wrapper">
        
        <header class="summit-hero">
            <div class="summit-container">
                <?php if($promoter_name): ?>
                    <div class="sh-promoter">
                        Presented by <?php if($promoter_link): ?><a href="<?= esc_url($promoter_link) ?>" target="_blank"><?= esc_html($promoter_name) ?> ↗</a><?php else: ?><strong><?= esc_html($promoter_name) ?></strong><?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="sh-badges">
                    <span class="sh-pill type"><?= $format === 'virtual' ? '🔴 Live Stream' : '🌐 Executive Summit' ?></span>
                    <span class="sh-pill date">📅 <?= date('M d', strtotime($start)) ?> - <?= date('M d', strtotime($end)) ?></span>
                </div>

                <h1><?php the_title(); ?></h1>
                <p class="sh-sub">📍 <?= esc_html($venue) ?></p>

                <div class="sh-actions">
                    <?php if($get('reg_link')): ?>
                        <a href="<?= esc_url($get('reg_link')) ?>" target="_blank" class="summit-btn primary">🎟️ Secure Delegate Pass</a>
                    <?php else: ?>
                        <button class="summit-btn primary" disabled>Registration Closed</button>
                    <?php endif; ?>
                    <button onclick="document.getElementById('vip-request').scrollIntoView({behavior: 'smooth'})" class="summit-btn ghost">💎 Request VIP Access</button>
                </div>
            </div>
            <div class="sh-glow"></div>
        </header>

        <div class="summit-score-strip animate-in">
            <div class="summit-container">
                <div class="d-score-grid">
                    <div class="ds-main">
                        <div class="ds-label">COI Authority Score</div>
                        <div class="ds-val"><?= $avg_score ?><span>/10</span></div>
                    </div>
                    <div class="ds-item">
                        <div class="ds-label">Content Quality</div>
                        <div class="ds-bar"><div class="fill" style="width:<?= $s_inn*10 ?>%"></div></div>
                        <div class="ds-num"><?= $s_inn ?></div>
                    </div>
                    <div class="ds-item">
                        <div class="ds-label">Networking</div>
                        <div class="ds-bar"><div class="fill" style="width:<?= $s_net*10 ?>%"></div></div>
                        <div class="ds-num"><?= $s_net ?></div>
                    </div>
                    <div class="ds-item">
                        <div class="ds-label">Speaker Caliber</div>
                        <div class="ds-bar"><div class="fill" style="width:<?= $s_roi*10 ?>%"></div></div>
                        <div class="ds-num"><?= $s_roi ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="summit-container">
            
            <section class="summit-intro animate-in">
                <div class="si-grid">
                    <div class="si-content">
                        <h3>Executive Brief</h3>
                        <div class="si-prose"><?php the_content(); ?></div>
                        
                        <?php if($format !== 'in-person' && $get('conf_link')): ?>
                        <div class="virtual-access-box">
                            <div class="vab-icon">📺</div>
                            <div class="vab-text"><strong>Digital Pass Included</strong><p>Stream all keynotes on-demand.</p></div>
                            <a href="<?= esc_url($get('conf_link')) ?>" target="_blank" class="vab-btn">Enter Hub →</a>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="si-demographics">
                        <h4>Who is in the Room?</h4>
                        <div class="sd-chart">
                            <div class="sd-row"><span class="sd-lbl">C-Level / Board</span><div class="sd-bar"><div class="sd-fill" style="width:45%"></div></div><span class="sd-val">45%</span></div>
                            <div class="sd-row"><span class="sd-lbl">VP / Directors</span><div class="sd-bar"><div class="sd-fill" style="width:30%"></div></div><span class="sd-val">30%</span></div>
                            <div class="sd-row"><span class="sd-lbl">Investors</span><div class="sd-bar"><div class="sd-fill" style="width:15%"></div></div><span class="sd-val">15%</span></div>
                        </div>
                        <div class="sd-footer">
                            <div class="sd-stat"><strong><?= esc_html($get('footfall') ?: '500+') ?></strong><span>Delegates</span></div>
                            <div class="sd-stat"><strong>85%</strong><span>Decision Makers</span></div>
                        </div>
                    </div>
                </div>
            </section>

            <?php if(!empty($speakers)): ?>
            <section class="summit-section animate-in delay-1">
                <h2>Headlining Speakers</h2>
                <div class="ss-grid">
                    <?php foreach($speakers as $speaker): $initials = substr($speaker, 0, 1); $bg = ['#f43f5e','#8b5cf6','#10b981'][rand(0,2)]; ?>
                    <div class="ss-card">
                        <div class="ss-avatar" style="background:linear-gradient(135deg, <?= $bg ?>, #111)"><?= $initials ?></div>
                        <div class="ss-info"><h4><?= esc_html($speaker) ?></h4><span>Keynote</span></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

            <section class="summit-section animate-in delay-1">
                <h2>Networking Experience</h2>
                <div class="networking-grid">
                    <div class="net-card">
                        <div class="nc-icon">🍸</div>
                        <h4>VIP Gala Dinner</h4>
                        <p>Exclusive evening for Speakers and Diamond pass holders.</p>
                    </div>
                    <div class="net-card">
                        <div class="nc-icon">⚡</div>
                        <h4>Speed Networking</h4>
                        <p>Curated 1:1 meetings based on your industry focus.</p>
                    </div>
                    <div class="net-card">
                        <div class="nc-icon">📱</div>
                        <h4>Event App Access</h4>
                        <p>Connect with delegates 1 week prior to the event.</p>
                    </div>
                </div>
            </section>

            <?php if($get('agenda')): ?>
            <section class="summit-section animate-in delay-1">
                <h2>Session Agenda</h2>
                <div class="sa-timeline">
                    <?php foreach(explode("\n", $get('agenda')) as $i => $item): ?>
                    <div class="sa-item">
                        <div class="sa-time">Session <?= $i+1 ?></div>
                        <div class="sa-content"><strong><?= esc_html($item) ?></strong><span>Main Stage</span></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

            <section id="vip-request" class="summit-footer-cta animate-in delay-2">
                <h2>Secure Your Access</h2>
                <p>Join the leaders shaping the future.</p>
                <div class="sfc-form-wrapper">
                    <form action="<?= esc_url(admin_url('admin-post.php')) ?>" method="POST" class="summit-inline-form">
                        <input type="hidden" name="action" value="cx_visitor_form"><input type="hidden" name="event_id" value="<?= $id ?>">
                        <?php wp_nonce_field('cx_visitor_action', '_cx_nonce'); ?>
                        <input type="text" name="cx_name" placeholder="Full Name" required>
                        <input type="email" name="cx_email" placeholder="Corporate Email" required>
                        <button type="submit">Request VIP Pass</button>
                    </form>
                    <small>Sponsorship inquiries: <a href="mailto:sponsor@coi.com" style="color:#6366f1">Contact Team</a></small>
                </div>
            </section>

        </div>
    </div>

<?php else: ?>

    <div class="cx-wrapper mode-expo">
        
        <div class="cx-hero-gradient">
            <div class="cx-container">
                
                <div class="hero-top-meta">
                    <span class="cx-badge date-badge">📅 <?= date('M d', strtotime($start)) ?> - <?= date('M d', strtotime($end)) ?></span>
                    <?php if($promoter_name): ?>
                        <span class="cx-badge promoter">Org: <?= esc_html($promoter_name) ?></span>
                    <?php endif; ?>
                    <span class="cx-badge space-status">⚡ Registration Open</span>
                </div>
                
                <h1 class="hero-title"><?php the_title(); ?></h1>
                <p class="hero-venue">📍 <?= esc_html($venue) ?></p>

                <div class="hero-data-strip">
                    <div class="hds-item">
                        <span class="hds-icon">👥</span>
                        <div class="hds-info">
                            <strong><?= esc_html($get('footfall') ?: 'TBA') ?></strong>
                            <span>Expected Visitors</span>
                        </div>
                    </div>
                    <div class="hds-item">
                        <span class="hds-icon">🏢</span>
                        <div class="hds-info">
                            <strong><?= esc_html($get('exhibitors') ?: 'TBA') ?></strong>
                            <span>Exhibitors</span>
                        </div>
                    </div>
                </div>
                
                <div class="hero-actions">
                    <button onclick="document.getElementById('free-pass').scrollIntoView({behavior:'smooth'})" class="cx-btn primary-light">
                        🎟️ Get Visitor Pass
                    </button>
                    <a href="mailto:sales@coi.com" class="cx-btn ghost-light">🎪 Book Booth Space</a>
                    
                    <?php 
                        $gcal = "https://www.google.com/calendar/render?action=TEMPLATE&text=" . urlencode(get_the_title()) . "&dates=" . date('Ymd', strtotime($start)) . "/" . date('Ymd', strtotime($end)) . "&location=" . urlencode($venue);
                    ?>
                    <a href="<?= $gcal ?>" target="_blank" class="cx-btn ghost-light icon-only" title="Add to Google Calendar">
                        📅 +
                    </a>
                </div>

            </div>
        </div>

        <div class="cx-score-strip animate-in">
            <div class="cx-container">
                <div class="score-box main-score">
                    <div class="sb-label">COI Event Score</div>
                    <div class="sb-val"><?= $avg_score ?><span>/10</span></div>
                </div>
                <div class="score-divider"></div>
                <div class="score-box">
                    <div class="sb-label">Innovation</div>
                    <div class="sb-bar"><div class="fill" style="width:<?= $s_inn*10 ?>%"></div></div>
                    <div class="sb-num"><?= $s_inn ?></div>
                </div>
                <div class="score-box">
                    <div class="sb-label">Networking</div>
                    <div class="sb-bar"><div class="fill" style="width:<?= $s_net*10 ?>%"></div></div>
                    <div class="sb-num"><?= $s_net ?></div>
                </div>
                <div class="score-box">
                    <div class="sb-label">ROI Potential</div>
                    <div class="sb-bar"><div class="fill" style="width:<?= $s_roi*10 ?>%"></div></div>
                    <div class="sb-num"><?= $s_roi ?></div>
                </div>
            </div>
        </div>

        <div class="cx-container cx-main-layout">
            
            <main class="cx-content">
                <section class="cx-card animate-in">
                    <h3 class="sec-heading">Expo Overview</h3>
                    <div class="cx-prose"><?php the_content(); ?></div>
                </section>

                <section class="cx-card">
                    <h3 class="sec-heading">Who Attends?</h3>
                    <div class="attendee-grid">
                        <div class="ag-chart">
                            <div class="chart-row"><span class="cr-label">Buyers</span><div class="cr-bar"><div class="cr-fill" style="width:50%"></div></div><span class="cr-val">50%</span></div>
                            <div class="chart-row"><span class="cr-label">Suppliers</span><div class="cr-bar"><div class="cr-fill" style="width:30%"></div></div><span class="cr-val">30%</span></div>
                        </div>
                        <div class="ag-info">
                            <h4>Top Industries</h4>
                            <div class="tag-cloud">
                                <?php $inds = $get('top_industries') ? explode(',', $get('top_industries')) : ['General Trade']; foreach($inds as $ind): ?>
                                    <span class="ag-tag"><?= trim($ind) ?></span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </section>

                <div class="cx-benefits-grid-card">
                    <div class="ben-card">
                        <h4>✅ Why Visit?</h4>
                        <ul><?php foreach(explode("\n", $get('why_attend')) as $l): ?><li><?= $l ?></li><?php endforeach; ?></ul>
                    </div>
                    <div class="ben-card highlight">
                        <h4>📈 Why Exhibit?</h4>
                        <ul><?php foreach(explode("\n", $get('why_exhibit')) as $l): ?><li><?= $l ?></li><?php endforeach; ?></ul>
                    </div>
                </div>

                <section class="cx-gallery-section">
                    <h3 class="sec-heading">Past Highlights</h3>
                    <div class="cx-gallery-grid">
                        <div class="gal-item" style="background:#e2e8f0;"></div>
                        <div class="gal-item" style="background:#cbd5e1;"></div>
                        <div class="gal-item" style="background:#94a3b8;"></div>
                    </div>
                </section>
            </main>

            <aside class="cx-sidebar animate-in delay-1">
                
                <div id="free-pass" class="cx-action-card highlight-blue">
                    <h3 class="form-title">🎟️ Free Visitor Pass</h3>
                    <p>Verified entry badge.</p>
                    <form action="<?= esc_url(admin_url('admin-post.php')) ?>" method="POST" class="cx-form-mini">
                        <input type="hidden" name="action" value="cx_visitor_form">
                        <input type="hidden" name="event_id" value="<?= $id ?>">
                        <?php wp_nonce_field('cx_visitor_action', '_cx_nonce'); ?>
                        <input type="text" name="cx_name" placeholder="Full Name" required>
                        <input type="email" name="cx_email" placeholder="Business Email" required>
                        <button type="submit" class="cx-btn primary full">🚀 Request Badge</button>
                    </form>
                </div>

                <div class="cx-action-card highlight-gold">
                    <span class="deal-badge">OPEN FOR BOOKING</span>
                    <h3>🎪 Book Floor Space</h3>
                    <p>Secure your spot on the floor.</p>
                    <a href="mailto:sales@coi.com?subject=Booth Enquiry: <?php the_title(); ?>" class="cx-btn secondary full">Enquire for Space</a>
                </div>

                <?php if($promoter_name): ?>
                <div class="cx-action-card">
                    <h3>📢 Organizer</h3>
                    <p>Managed by <strong><?= esc_html($promoter_name) ?></strong>.</p>
                    <?php if($promoter_link): ?>
                        <a href="<?= esc_url($promoter_link) ?>" target="_blank" class="cx-link-light">Visit Official Site →</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

            </aside>
        </div>
    </div>

<?php endif; ?>
<?php get_footer(); ?>