document.addEventListener("DOMContentLoaded", function () {
    
    // Function to initialize charts safely
    function initCOICharts() {
        // 1. CHECK: Is Chart.js loaded?
        if (typeof Chart === 'undefined') {
            console.warn("COI: Chart.js library not ready yet. Retrying in 500ms...");
            setTimeout(initCOICharts, 500); // Wait 0.5s and try again
            return;
        }

        console.log("COI: Library found. Initializing charts...");

        // --- CHART 1: GROWTH ---
        const growthCanvas = document.getElementById('coiGrowthChart');
        if (growthCanvas) {
            // Destroy existing chart if it exists (prevents duplicates)
            if (window.coiGrowthInstance) window.coiGrowthInstance.destroy();

            const rawValues = growthCanvas.getAttribute('data-values') || "0,0,0,0";
            const dataArr = rawValues.split(',').map(num => parseFloat(num.trim()) || 0);

            window.coiGrowthInstance = new Chart(growthCanvas, {
                type: 'line',
                data: {
                    labels: ['Q1', 'Q2', 'Q3', 'Q4'],
                    datasets: [{
                        label: 'Growth',
                        data: dataArr,
                        borderColor: '#2563eb',
                        backgroundColor: 'rgba(37, 99, 235, 0.1)',
                        borderWidth: 3,
                        tension: 0.4,
                        fill: true,
                        pointBackgroundColor: '#fff',
                        pointBorderColor: '#2563eb',
                        pointRadius: 5
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false, // Critical for filling height
                    plugins: { legend: { display: false } },
                    scales: {
                        y: { beginAtZero: true, grid: { borderDash: [5, 5] } },
                        x: { grid: { display: false } }
                    }
                }
            });
        }

        // --- CHART 2: RADAR ---
        const radarCanvas = document.getElementById('coiRadarChart');
        if (radarCanvas) {
            if (window.coiRadarInstance) window.coiRadarInstance.destroy();

            const rawRadar = radarCanvas.getAttribute('data-values') || "5,5,5,5,5";
            const radarArr = rawRadar.split(',').map(num => parseFloat(num.trim()) || 0);

            window.coiRadarInstance = new Chart(radarCanvas, {
                type: 'radar',
                data: {
                    labels: ['Impact', 'Innov.', 'Scale', 'Feasib.', 'Team'],
                    datasets: [{
                        label: 'Score',
                        data: radarArr,
                        backgroundColor: 'rgba(16, 185, 129, 0.2)',
                        borderColor: '#10b981',
                        borderWidth: 2,
                        pointBackgroundColor: '#10b981'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        r: {
                            angleLines: { color: '#e2e8f0' },
                            grid: { color: '#e2e8f0' },
                            pointLabels: { font: { size: 11, weight: 'bold' } },
                            suggestedMin: 0,
                            suggestedMax: 10
                        }
                    }
                }
            });
        }
    }

    // Start the process
    initCOICharts();
});