document.addEventListener("DOMContentLoaded", () => {
  const el = document.getElementById("impactChart");
  if (!el) return;

  new Chart(el,{
    type:'line',
    data:{
      labels:['Jan','Feb','Mar','Apr','May','Jun'],
      datasets:[{
        data:[1200,1500,1800,2200,2800,3200],
        fill:true,
        borderColor:'#0ea5e9',
        backgroundColor:'rgba(14,165,233,.2)'
      }]
    },
    options:{plugins:{legend:{display:false}}}
  });
});
