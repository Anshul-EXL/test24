<?php
/**
 * Archive Template - Innovation Search Engine
 */
get_header();

// 1. FILTER INPUTS
$filter_sector = isset($_GET['sector']) ? sanitize_text_field($_GET['sector']) : '';
$filter_trl    = isset($_GET['trl']) ? sanitize_text_field($_GET['trl']) : '';
$filter_verify = isset($_GET['verified']) ? sanitize_text_field($_GET['verified']) : '';
$sort_by       = isset($_GET['sort']) ? sanitize_text_field($_GET['sort']) : 'date';

// 2. GET SECTORS (TAXONOMY)
$sectors = get_terms(['taxonomy' => 'coi_category', 'hide_empty' => false]);
?>

<div class="coi-wrapper">
    <div class="coi-container">
        
        <div class="archive-header">
            <h1>Innovation Intelligence</h1>
            <p>Search verified technologies evaluated by the Council.</p>
        </div>

        <div class="search-layout">
            
            <aside class="search-sidebar">
                <form method="GET" class="filter-form">
                    
                    <div class="filter-group">
                        <label>Keywords</label>
                        <input type="text" name="s" placeholder="e.g. AI, Logistics..." value="<?php echo get_search_query(); ?>">
                    </div>

                    <div class="filter-group">
                        <label>Sector</label>
                        <select name="sector" onchange="this.form.submit()">
                            <option value="">All Sectors</option>
                            <?php foreach($sectors as $s): ?>
                                <option value="<?php echo $s->slug; ?>" <?php selected($filter_sector, $s->slug); ?>>
                                    <?php echo $s->name; ?> (<?php echo $s->count; ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label>Maturity (TRL)</label>
                        <select name="trl" onchange="this.form.submit()">
                            <option value="">Any Stage</option>
                            <option value="high" <?php selected($filter_trl, 'high'); ?>>Market Ready (7-9)</option>
                            <option value="mid" <?php selected($filter_trl, 'mid'); ?>>Prototype (4-6)</option>
                            <option value="low" <?php selected($filter_trl, 'low'); ?>>Research (1-3)</option>
                        </select>
                    </div>

                    <div class="filter-group toggle-group">
                        <label>
                            <input type="checkbox" name="verified" value="1" <?php checked($filter_verify, '1'); ?> onchange="this.form.submit()">
                            <span>Verified Only 🛡️</span>
                        </label>
                    </div>

                    <div class="filter-group">
                        <label>Sort By</label>
                        <select name="sort" onchange="this.form.submit()">
                            <option value="date" <?php selected($sort_by, 'date'); ?>>Newest Added</option>
                            <option value="score" <?php selected($sort_by, 'score'); ?>>Highest Score</option>
                        </select>
                    </div>

                    <a href="?post_type=coi_innovation" class="reset-link">Reset Filters</a>
                </form>
            </aside>

            <main class="results-grid">
                <?php
                $args = [
                    'post_type' => 'coi_innovation',
                    'posts_per_page' => 12,
                    'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
                    'meta_query' => [],
                    'tax_query' => []
                ];

                if (get_search_query()) $args['s'] = get_search_query();
                if ($filter_sector) $args['tax_query'][] = ['taxonomy' => 'coi_category', 'field' => 'slug', 'terms' => $filter_sector];
                if ($filter_verify) $args['meta_query'][] = ['key' => '_coi_verified', 'value' => '1', 'compare' => '='];
                
                if ($filter_trl == 'high') $args['meta_query'][] = ['key' => '_coi_trl', 'value' => 7, 'compare' => '>=', 'type' => 'NUMERIC'];
                if ($filter_trl == 'mid')  $args['meta_query'][] = ['key' => '_coi_trl', 'value' => [4,6], 'compare' => 'BETWEEN', 'type' => 'NUMERIC'];
                if ($filter_trl == 'low')  $args['meta_query'][] = ['key' => '_coi_trl', 'value' => 3, 'compare' => '<=', 'type' => 'NUMERIC'];

                if ($sort_by == 'score') {
                    $args['meta_key'] = '_coi_score_avg';
                    $args['orderby'] = 'meta_value_num';
                    $args['order'] = 'DESC';
                }

                $query = new WP_Query($args);

                if ($query->have_posts()) : 
                    echo '<div class="cards-wrapper">';
                    while ($query->have_posts()) : $query->the_post();
                        $id = get_the_ID();
                        $score = get_post_meta($id, '_coi_score_avg', true) ?: '-';
                        $terms = get_the_terms($id, 'coi_category');
                        $sector = $terms ? $terms[0]->name : 'Uncategorized';
                        $verified = get_post_meta($id, '_coi_verified', true);
                ?>

                <a href="<?php the_permalink(); ?>" class="result-card">
                    <div class="card-head">
                        <span class="sector-pill"><?php echo esc_html($sector); ?></span>
                        <?php if($verified): ?><span class="verified-icon">🛡️</span><?php endif; ?>
                    </div>
                    
                    <div class="card-body">
                        <div class="card-logo">
                            <?php if(has_post_thumbnail()){ the_post_thumbnail('thumbnail'); } else { echo '🚀'; } ?>
                        </div>
                        <h3><?php the_title(); ?></h3>
                        <p class="company"><?php echo esc_html(get_post_meta($id, '_coi_company', true)); ?></p>
                        <div class="card-desc"><?php echo wp_trim_words(get_the_excerpt(), 10); ?></div>
                    </div>

                    <div class="card-foot">
                        <div class="metric">
                            <span class="lbl">COI Score</span>
                            <span class="val <?php echo ($score >= 8) ? 'high' : ''; ?>"><?php echo $score; ?></span>
                        </div>
                        <div class="metric">
                            <span class="lbl">Details</span>
                            <span class="val arrow">→</span>
                        </div>
                    </div>
                </a>

                <?php endwhile; echo '</div>'; ?>
                
                <div class="pagination">
                    <?php echo paginate_links(['total' => $query->max_num_pages, 'prev_text' => '←', 'next_text' => '→']); ?>
                </div>

                <?php else: ?>
                    <div class="no-results">
                        <h3>No innovations found.</h3>
                        <p>Try adjusting filters.</p>
                        <a href="?post_type=coi_innovation" class="btn-reset">Reset</a>
                    </div>
                <?php endif; wp_reset_postdata(); ?>
            </main>
        </div>
    </div>
</div>
<?php get_footer(); ?>