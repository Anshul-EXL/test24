<?php
/**
 * Single Innovation - "Facilitated Connect" Edition (v22)
 */
get_header();

$id = get_the_ID();
$get = fn($k) => get_post_meta($id, "_coi_$k", true);

// DATA
$rev_json = $get('revenue_json') ?: '{}';
$market_json = $get('market_share') ?: '{}';
$score = get_post_meta($id, '_coi_score_avg', true) ?: 'N/A';
$is_verified = ($get('verified') === '1'); 
$logo = has_post_thumbnail() ? get_the_post_thumbnail_url($id, 'medium') : '';
$competitors = $get('competitors');
$pros = array_filter(explode("\n", $get('pros')));
$cons = array_filter(explode("\n", $get('cons')));
$date = $get('date') ? date('M Y', strtotime($get('date'))) : get_the_modified_date('M Y');
$trl = (int) ($get('trl') ?: 1);

// --- SMART TIER LOGIC ---
$tier_color = 'bronze'; $tier_name = 'Prototype'; $tier_desc = 'Early Stage Innovation';
if ($trl >= 9 && $is_verified) { $tier_color = 'gold'; $tier_name = 'Gold Standard'; $tier_desc = 'Market Ready & Verified'; } 
elseif ($trl >= 7) { $tier_color = 'silver'; $tier_name = 'Silver Tier'; $tier_desc = 'Pilot Ready Solution'; }

// --- FACILITATION LOGIC (Pre-filled Email) ---
$contact_email = $get('contact_email');
$subject = rawurlencode("Opportunity regarding " . get_the_title() . " (via Council of Innovation)");
$body = rawurlencode("Hello,\n\nI reviewed your innovation profile for '" . get_the_title() . "' on the Council of Innovation platform.\n\nWe are interested in exploring potential collaboration/investment opportunities.\n\nBest regards,");
$mailto_link = "mailto:{$contact_email}?subject={$subject}&body={$body}";
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="coi-wrapper">
    <div class="coi-container">

        <header class="coi-header-pro animate-in">
            <div class="header-main">
                <div class="coi-logo-pro">
                    <?php if($logo): ?><img src="<?= $logo ?>"><?php else: ?><span><?= substr(get_the_title(),0,1) ?></span><?php endif; ?>
                </div>
                <div class="header-details">
                    <div class="header-top-row">
                        <span class="industry-tag"><?= esc_html($get('location')) ?></span>
                        <span class="industry-tag"><?= esc_html($get('stage') ?: 'Growth') ?></span>
                    </div>
                    <h1><?php the_title(); ?></h1>
                    <p class="company-name"><?= esc_html($get('company')) ?> • Led by <strong><?= esc_html($get('founder')) ?></strong></p>
                    
                    <div class="header-actions">
                        <button onclick="document.getElementById('contact-area').scrollIntoView({behavior: 'smooth'})" class="btn-action primary">
                            🤝 Connect with Innovator
                        </button>
                    </div>
                </div>
            </div>
            <?php if($is_verified): ?>
            <div class="coi-iso-badge">
                <div class="iso-inner">
                    <span class="iso-top">COI COUNCIL</span>
                    <span class="iso-grade">A+</span>
                    <span class="iso-bottom">VERIFIED</span>
                </div>
            </div>
            <?php endif; ?>
        </header>

        <div class="coi-layout-grid">
            <main class="coi-main">
                
                <section class="pro-card animate-in delay-1">
                    <div class="card-head"><h3>🔬 The Innovation Core</h3></div>
                    <div class="deep-dive-grid">
                        <div class="dive-col problem">
                            <h4>The Pain Point</h4>
                            <p><?= nl2br(esc_html($get('problem'))) ?></p>
                        </div>
                        <div class="dive-col highlight solution">
                            <h4>The Solution</h4>
                            <p><?= nl2br(esc_html($get('solution'))) ?></p>
                        </div>
                    </div>
                </section>

                <section class="impact-tier-section animate-in delay-2">
                    <div class="impact-box">
                        <div class="ib-head"><h4>⚡ Verified Impact</h4><span class="live-dot">● Validated</span></div>
                        <div class="impact-grid">
                            <?php 
                            $metrics = explode("\n", $get('metrics'));
                            foreach($metrics as $m): $p = explode('|', $m); if(count($p)>=2):
                            ?>
                            <div class="roi-stat">
                                <span class="roi-val"><?= esc_html(trim($p[1])) ?></span>
                                <span class="roi-lbl"><?= esc_html(trim($p[0])) ?></span>
                            </div>
                            <?php endif; endforeach; ?>
                        </div>
                    </div>
                    <div class="tier-box tier-<?= $tier_color ?>">
                        <div class="tier-content">
                            <span class="tier-label">CERTIFICATION</span>
                            <h2 class="tier-title"><?= $tier_name ?></h2>
                            <p class="tier-desc"><?= $tier_desc ?></p>
                            <div class="tier-bar"><div class="tier-fill" style="width: <?= ($trl/9)*100 ?>%"></div></div>
                            <span class="tier-trl">TRL <?= $trl ?>/9</span>
                        </div>
                    </div>
                </section>

                <section class="pro-card animate-in delay-2">
                    <div class="card-head"><h3>📊 Market Traction</h3></div>
                    <div class="charts-row">
                        <div class="chart-col">
                            <h4>Revenue History ($M)</h4>
                            <div class="chart-box"><canvas id="revenueChart"></canvas></div>
                        </div>
                        <div class="chart-col">
                            <h4>Market Share</h4>
                            <div class="chart-box"><canvas id="marketChart"></canvas></div>
                        </div>
                    </div>
                </section>

                <section class="pro-card analyst-card animate-in delay-3">
                    <div class="card-head"><h3>🧠 Analyst Verdict: <span style="color:#2563eb;"><?= esc_html($get('verdict_label')) ?></span></h3></div>
                    <div class="pros-cons-grid">
                        <div class="pc-col summary"><p class="summary-text">"<?= nl2br(esc_html($get('analyst_summary'))) ?>"</p></div>
                        <div class="pc-col lists">
                            <div class="pros"><h4>✅ Pros</h4><ul><?php foreach($pros as $p): ?><li><?= esc_html($p) ?></li><?php endforeach; ?></ul></div>
                            <div class="cons" style="margin-top:10px;"><h4>⚠️ Risks</h4><ul><?php foreach($cons as $c): ?><li><?= esc_html($c) ?></li><?php endforeach; ?></ul></div>
                        </div>
                    </div>
                </section>

                <?php if($get('use_cases')): ?>
                <section class="pro-card animate-in delay-3">
                    <div class="card-head"><h3>🛠️ Use Cases</h3></div>
                    <div class="usecase-grid-big">
                    <?php foreach(explode("\n", $get('use_cases')) as $c): $p = explode('||', $c); if(count($p)>=2): $img = trim($p[2] ?? ''); ?>
                        <div class="uc-card-big">
                            <div class="uc-thumb-big" style="<?php echo $img ? "background-image:url('$img')" : "background:#f1f5f9"; ?>"><?php if(!$img) echo '💡'; ?></div>
                            <div class="uc-content-big"><h5><?= esc_html(trim($p[0])) ?></h5><p><?= esc_html(trim($p[1])) ?></p></div>
                        </div>
                    <?php endif; endforeach; ?>
                    </div>
                </section>
                <?php endif; ?>

            </main>

            <aside class="coi-sidebar animate-in delay-1">
                
                <div id="contact-area" class="pro-card sidebar-widget sticky-widget">
                    <h4>Direct Connection</h4>
                    <p style="font-size:12px; color:#64748b; margin-bottom:15px;">
                        The Council facilitates direct intros to high-potential innovators.
                    </p>
                    
                    <a href="<?= $mailto_link ?>" class="btn-contact">
                        ✉️ Connect with Innovator
                    </a>
                    
                    <div style="margin-top:10px; font-size:10px; text-align:center; color:#94a3b8;">
                        🔒 Secure Introduction via COI
                    </div>
                </div>

                <div class="pro-card sidebar-widget">
                    <h4>Scorecard</h4>
                    <div style="height:220px"><canvas id="radarChart"></canvas></div>
                </div>

                <div class="pro-card sidebar-widget">
                    <h4>Research Assets</h4>
                    <?php if($get('deck')): ?><a href="<?= esc_url($get('deck')) ?>" target="_blank" class="btn-dl primary">📥 Pitch Deck</a><?php endif; ?>
                    <?php if($get('case_study')): ?><a href="<?= esc_url($get('case_study')) ?>" target="_blank" class="btn-dl secondary">📄 Case Study</a><?php endif; ?>
                </div>

            </aside>
        </div>

        <section class="coi-cta-footer animate-in delay-3">
            <div class="cta-inner">
                <h2>Have an Innovation?</h2>
                <div class="cta-buttons"><a href="/submit" class="cta-btn primary">🚀 Submit for Review</a></div>
            </div>
        </section>

    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const revRaw = <?php echo $rev_json; ?>;
    new Chart(document.getElementById('revenueChart'), { type: 'bar', data: { labels: Object.keys(revRaw), datasets: [{ label: 'Revenue ($M)', data: Object.values(revRaw), backgroundColor: '#3b82f6', borderRadius: 4 }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } } });

    const mktRaw = <?php echo $market_json; ?>;
    new Chart(document.getElementById('marketChart'), { type: 'doughnut', data: { labels: Object.keys(mktRaw), datasets: [{ data: Object.values(mktRaw), backgroundColor: ['#0f172a', '#334155', '#64748b', '#cbd5e1'] }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { boxWidth: 10 } } } } });

    new Chart(document.getElementById('radarChart'), { type: 'radar', data: { labels: ['Impact', 'Innovation', 'Scale', 'Feasib.', 'Team'], datasets: [{ data: [<?= esc_js($get('chart_radar') ?: '0,0,0,0,0') ?>], backgroundColor: 'rgba(37, 99, 235, 0.2)', borderColor: '#2563eb', borderWidth: 1.5 }] }, options: { responsive: true, maintainAspectRatio: false, scales: { r: { ticks: { display: false }, suggestedMin: 0, suggestedMax: 10 } } } });
});
</script>

<?php get_footer(); ?>