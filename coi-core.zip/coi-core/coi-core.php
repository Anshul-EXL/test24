<?php
/**
 * Plugin Name: COI Core – Innovation Intelligence (Ultimate Edition)
 * Description: The complete Innovation Dashboard with Financial Charts, Tech Specs, and Analyst Verdicts.
 * Version: 17.0.0
 * Author: COI
 */

if (!defined('ABSPATH')) exit;

/* ======================================================
   1. REGISTER POST TYPE
   ====================================================== */
add_action('init', function () {
    add_theme_support('post-thumbnails');
    register_post_type('coi_innovation', [
        'labels' => ['name' => 'Innovations', 'singular_name' => 'Profile', 'add_new_item' => 'Add Profile'],
        'public' => true,
        'menu_icon' => 'dashicons-chart-area',
        'supports' => ['title', 'editor', 'excerpt', 'thumbnail'],
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'innovations', 'with_front' => false], 
        'has_archive' => true
    ]);
    register_taxonomy('coi_category', 'coi_innovation', [
        'labels' => ['name' => 'Sectors', 'singular_name' => 'Sector'],
        'hierarchical' => true,
        'show_ui' => true,
        'rewrite' => ['slug' => 'sector', 'with_front' => false],
    ]);
});

/* ======================================================
   2. REGISTER META BOXES
   ====================================================== */
add_action('add_meta_boxes', function () {
    add_meta_box('coi_data_box', 'Intelligence Data Suite', 'coi_render_meta_box', 'coi_innovation', 'normal', 'high');
});

function coi_render_meta_box($post) {
    wp_nonce_field('coi_save_meta', 'coi_nonce');
    $get = fn($k) => get_post_meta($post->ID, "_coi_$k", true);
    ?>
    <style>
        .coi-wrap { background: #f8fafc; padding: 25px; border: 1px solid #e2e8f0; }
        .coi-section { font-size: 13px; font-weight: 800; text-transform: uppercase; color: #0f172a; border-bottom: 2px solid #3b82f6; padding-bottom: 8px; margin: 30px 0 15px 0; }
        .coi-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 15px; }
        .coi-col-2 { grid-column: span 2; }
        .coi-field label { display: block; font-weight: 600; font-size: 12px; color: #334155; margin-bottom: 5px; }
        .coi-field input, .coi-field textarea, .coi-field select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; }
    </style>

    <div class="coi-wrap">
        
        <div class="coi-section" style="margin-top:0;">🏢 Firmographics (The Ticker)</div>
        <div class="coi-grid">
            <div class="coi-field"><label>Company</label><input name="coi_company" value="<?= esc_attr($get('company')) ?>"></div>
            <div class="coi-field"><label>Founder</label><input name="coi_founder" value="<?= esc_attr($get('founder')) ?>"></div>
            <div class="coi-field"><label>Location</label><input name="coi_location" value="<?= esc_attr($get('location')) ?>"></div>
        </div>
        <div class="coi-grid">
            <div class="coi-field"><label>Total Raised</label><input name="coi_raised" placeholder="$10M" value="<?= esc_attr($get('raised')) ?>"></div>
            <div class="coi-field"><label>Est. Valuation</label><input name="coi_valuation" placeholder="$50M" value="<?= esc_attr($get('valuation')) ?>"></div>
            <div class="coi-field"><label>Employees</label><input name="coi_employees" placeholder="50-100" value="<?= esc_attr($get('employees')) ?>"></div>
        </div>

        <div class="coi-section">📊 Financial Charts</div>
        <div class="coi-grid">
            <div class="coi-field coi-col-2">
                <label>Revenue History JSON (Bar Chart)</label>
                <textarea name="coi_revenue_json" rows="3" placeholder='{"2021": 2.5, "2022": 5.0, "2023": 12.0}'><?= esc_textarea($get('revenue_json')) ?></textarea>
            </div>
            <div class="coi-field">
                <label>Market Share JSON (Pie Chart)</label>
                <textarea name="coi_market_share" rows="3" placeholder='{"Company": 40, "Others": 60}'><?= esc_textarea($get('market_share')) ?></textarea>
            </div>
        </div>

        <div class="coi-section">🧠 Analyst Verdict</div>
        <div class="coi-grid">
            <div class="coi-field"><label>Analyst Name</label><input name="coi_analyst" value="<?= esc_attr($get('analyst')) ?>"></div>
            <div class="coi-field"><label>Audit Date</label><input type="date" name="coi_date" value="<?= esc_attr($get('date')) ?>"></div>
            <div class="coi-field"><label>Verdict Label</label><input name="coi_verdict_label" placeholder="Market Leader" value="<?= esc_attr($get('verdict_label')) ?>"></div>
        </div>
        <div class="coi-field"><label>Summary</label><textarea name="coi_analyst_summary" rows="3"><?= esc_textarea($get('analyst_summary')) ?></textarea></div>
        <div class="coi-grid" style="margin-top:10px;">
            <div class="coi-field coi-col-2"><label>✅ Pros (One per line)</label><textarea name="coi_pros" rows="4"><?= esc_textarea($get('pros')) ?></textarea></div>
            <div class="coi-field"><label>❌ Cons (One per line)</label><textarea name="coi_cons" rows="4"><?= esc_textarea($get('cons')) ?></textarea></div>
        </div>

        <div class="coi-section">💡 Tech & Innovation</div>
        <div class="coi-grid">
            <div class="coi-field coi-col-2"><label>Problem</label><textarea name="coi_problem" rows="3"><?= esc_textarea($get('problem')) ?></textarea></div>
            <div class="coi-field coi-col-2"><label>Solution</label><textarea name="coi_solution" rows="3"><?= esc_textarea($get('solution')) ?></textarea></div>
        </div>
        <div class="coi-grid">
            <div class="coi-field"><label>Radar Score (1-10)</label><input name="coi_chart_radar" value="<?= esc_attr($get('chart_radar')) ?>"></div>
            <div class="coi-field"><label>TRL (1-9)</label><input type="number" name="coi_trl" value="<?= esc_attr($get('trl')) ?>"></div>
            <div class="coi-field"><label>Verified?</label><select name="coi_verified"><option value="">No</option><option value="1" <?= selected($get('verified'), '1') ?>>Yes</option></select></div>
        </div>

        <div class="coi-section">📂 Assets & Contact</div>
        <div class="coi-grid">
            <div class="coi-field"><label>Deck URL</label><input name="coi_deck" value="<?= esc_attr($get('deck')) ?>"></div>
            <div class="coi-field"><label>Video URL</label><input name="coi_video" value="<?= esc_attr($get('video')) ?>"></div>
            <div class="coi-field"><label>Case Study URL</label><input name="coi_case_study" value="<?= esc_attr($get('case_study')) ?>"></div>
        </div>
        <div class="coi-grid">
            <div class="coi-field"><label>Contact Email</label><input name="coi_contact_email" value="<?= esc_attr($get('contact_email')) ?>"></div>
            <div class="coi-field"><label>Website</label><input name="coi_website" value="<?= esc_attr($get('website')) ?>"></div>
            <div class="coi-field"><label>Competitors</label><input name="coi_competitors" placeholder="Comp A, Comp B" value="<?= esc_attr($get('competitors')) ?>"></div>
        </div>
        <div class="coi-grid">
            <div class="coi-field"><label>Use Cases</label><textarea name="coi_use_cases" rows="4"><?= esc_textarea($get('use_cases')) ?></textarea></div>
            <div class="coi-field"><label>Metrics List</label><textarea name="coi_metrics" rows="4"><?= esc_textarea($get('metrics')) ?></textarea></div>
            <div class="coi-field"><label>Tech Specs</label><textarea name="coi_tech_specs" rows="4"><?= esc_textarea($get('tech_specs')) ?></textarea></div>
        </div>
    </div>
    <?php
}

/* ======================================================
   3. SAVE DATA
   ====================================================== */
add_action('save_post_coi_innovation', function ($post_id) {
    if (!isset($_POST['coi_nonce']) || !wp_verify_nonce($_POST['coi_nonce'], 'coi_save_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    $fields = ['company','founder','location','raised','valuation','employees','revenue_json','market_share','analyst','date','verdict_label','analyst_summary','pros','cons','problem','solution','chart_radar','trl','verified','deck','video','case_study','contact_email','website','competitors','use_cases','metrics','tech_specs'];
    
    foreach ($fields as $f) {
        if (isset($_POST["coi_$f"])) {
            $val = (strpos($f, 'json') !== false || strpos($f, 'share') !== false) ? stripslashes($_POST["coi_$f"]) : sanitize_text_field($_POST["coi_$f"]);
            if (in_array($f, ['metrics', 'use_cases', 'tech_specs', 'pros', 'cons', 'problem', 'solution', 'analyst_summary'])) $val = sanitize_textarea_field($_POST["coi_$f"]);
            update_post_meta($post_id, "_coi_$f", $val);
        }
    }
    // Auto Score
    if (isset($_POST['coi_chart_radar'])) {
        $points = explode(',', sanitize_text_field($_POST['coi_chart_radar']));
        $sum = 0; $count = 0;
        foreach($points as $p) { $val = floatval(trim($p)); if($val > 0) { $sum += $val; $count++; } }
        $avg_score = ($count > 0) ? round($sum / $count, 1) : 0;
        update_post_meta($post_id, '_coi_score_avg', $avg_score);
    }
});

/* ======================================================
   4. LOADERS
   ====================================================== */
add_filter('template_include', function ($template) {
    if (is_singular('coi_innovation')) return plugin_dir_path(__FILE__) . 'templates/single-coi_innovation.php';
    if (is_post_type_archive('coi_innovation') || is_tax('coi_category')) return plugin_dir_path(__FILE__) . 'templates/archive-coi_innovation.php';
    return $template;
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('coi-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
    if (is_singular('coi_innovation')) wp_enqueue_style('coi-single', plugin_dir_url(__FILE__) . 'assets/coi-style.css', [], '17.0');
    if (is_post_type_archive('coi_innovation') || is_tax('coi_category')) wp_enqueue_style('coi-archive', plugin_dir_url(__FILE__) . 'assets/coi-archive.css', [], '17.0');
});

/* ======================================================
   7. ULTIMATE JSON IMPORTER (Supports All Fields)
   ====================================================== */

add_action('admin_menu', function() {
    add_submenu_page('edit.php?post_type=coi_innovation', 'Import Data', 'Import Data', 'manage_options', 'coi-import', 'coi_render_import_page');
});

function coi_render_import_page() {
    if (isset($_POST['coi_json_data']) && check_admin_referer('coi_import', 'coi_nonce')) {
        $data = json_decode(stripslashes($_POST['coi_json_data']), true);
        
        if (!$data) {
            echo '<div class="notice notice-error"><p>❌ Invalid JSON.</p></div>';
        } else {
            $count = 0;
            foreach ($data as $item) {
                // 1. Check if post exists (avoid duplicates by title)
                $exist = get_page_by_title($item['title'], OBJECT, 'coi_innovation');
                
                if ($exist) {
                    $post_id = $exist->ID; // Update existing
                } else {
                    $post_id = wp_insert_post([
                        'post_title'   => $item['title'],
                        'post_type'    => 'coi_innovation',
                        'post_status'  => 'publish',
                        'post_excerpt' => substr($item['problem'], 0, 150) . '...'
                    ]);
                }

                if ($post_id) {
                    $count++;
                    
                    // 2. Map All Simple Fields
                    $keys = [
                        'company', 'founder', 'location', 'website', 'linkedin', 'linkedin_followers',
                        'stage', 'raised', 'valuation', 'revenue', 'employees',
                        'problem', 'solution', 'trl', 'verified',
                        'analyst', 'analyst_title', 'analyst_summary', 'verdict_label', 'date',
                        'pros', 'cons', 'metrics', 'tech_specs', 'use_cases',
                        'revenue_json', 'market_share', 'chart_radar', 'chart_growth',
                        'video', 'deck', 'case_study', 'contact_email', 'competitors'
                    ];

                    foreach ($keys as $key) {
                        if (isset($item[$key])) {
                            // If it's an array/object in JSON, convert to string for WP Meta
                            $val = is_array($item[$key]) ? json_encode($item[$key]) : $item[$key];
                            update_post_meta($post_id, "_coi_$key", $val);
                        }
                    }

                    // 3. Set Sector (Taxonomy)
                    if (!empty($item['sector'])) {
                        wp_set_object_terms($post_id, $item['sector'], 'coi_category');
                    }

                    // 4. Auto-Calc Score
                    if (!empty($item['chart_radar'])) {
                        $points = explode(',', $item['chart_radar']);
                        $avg = array_sum($points) / count($points);
                        update_post_meta($post_id, '_coi_score_avg', round($avg, 1));
                    }
                }
            }
            echo '<div class="notice notice-success"><p>✅ Successfully processed ' . $count . ' innovations!</p></div>';
        }
    }
    ?>
    <div class="wrap">
        <h1>🚀 Bulk Intelligence Importer</h1>
        <p>Paste your JSON array below to populate the dashboard.</p>
        <form method="post">
            <?php wp_nonce_field('coi_import', 'coi_nonce'); ?>
            <textarea name="coi_json_data" rows="20" style="width:100%; font-family:monospace; background:#282c34; color:#abb2bf; padding:15px; border-radius:5px;"></textarea>
            <p><input type="submit" class="button button-primary button-large" value="Run Import"></p>
        </form>
    </div>
    <?php
}