jQuery(document).on('click', '.add-row', function () {
    const target = jQuery('#' + jQuery(this).data('target'));
    const index = target.children().length;
    const clone = target.children().last().clone();
    clone.find('input,textarea').val('');
    clone.html(clone.html().replace(/\[\d+\]/g, '[' + index + ']'));
    target.append(clone);
});

jQuery(document).on('click', '.remove', function () {
    jQuery(this).parent().remove();
});
