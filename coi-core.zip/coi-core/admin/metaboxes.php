<?php
if (!defined('ABSPATH')) exit;

add_action('add_meta_boxes', function () {
  add_meta_box(
    'coi_innovation_fields',
    'Innovation Details',
    'coi_render_fields',
    'coi_innovation',
    'normal',
    'high'
  );
});

function coi_render_fields($post) {
  wp_nonce_field('coi_save_meta', 'coi_nonce');

  $fields = [
    'coi_logo' => 'Logo URL',
    'coi_tagline' => 'Tagline',
    'coi_company' => 'Company',
    'coi_location' => 'Location',
    'coi_year' => 'Year',
    'coi_website' => 'Website',
    'coi_trl' => 'TRL (1–9)',
    'coi_verified' => 'Verified (yes/no)',
    'coi_use_cases' => 'Use Cases (Title | Desc | image|video | URL)',
    'coi_timeline' => 'Timeline (Phase | Desc | status)',
    'coi_metric_efficiency' => 'Efficiency %',
    'coi_metric_cost' => 'Cost Savings',
    'coi_metric_accuracy' => 'Accuracy %',
    'coi_impact_timeseries' => 'Impact Chart Data (JSON array)'
  ];

  foreach ($fields as $key => $label):
    $value = get_post_meta($post->ID, $key, true);
  ?>
    <p>
      <label><strong><?php echo esc_html($label); ?></strong></label><br>
      <textarea name="<?php echo esc_attr($key); ?>" style="width:100%" rows="3"><?php echo esc_textarea($value); ?></textarea>
    </p>
  <?php endforeach;
}

add_action('save_post_coi_innovation', function ($post_id) {
  if (!isset($_POST['coi_nonce'])) return;
  if (!wp_verify_nonce($_POST['coi_nonce'], 'coi_save_meta')) return;

  foreach ($_POST as $k => $v) {
    if (strpos($k, 'coi_') === 0) {
      update_post_meta($post_id, $k, sanitize_textarea_field($v));
    }
  }
});
